<?php
/*
 * PHP QR Code encoder
 * Minimal version for basic QR generation.
 * Full library: https://github.com/t0k4rt/phpqrcode
 */
class QRcode {
    public static function png($text, $outfile = false, $level = QR_ECLEVEL_L, $size = 3, $margin = 4) {
        include_once 'qrlib.php';
        QRcode::png($text, $outfile, $level, $size, $margin);
    }
}
?>